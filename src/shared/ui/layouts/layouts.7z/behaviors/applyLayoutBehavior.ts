import type { LayoutBehavior, BehaviorStyles } from './types';

/**
 * Returns CSS class names for layout behavior
 * 
 * @param behavior - 'default' or 'fixed-height'
 * @returns Object with className strings for each layout section
 */
export function applyLayoutBehavior(behavior: LayoutBehavior): BehaviorStyles {
  if (behavior === 'fixed-height') {
    return {
      root: 'h-dvh overflow-hidden',
      sidebar: 'h-full overflow-hidden',
      content: 'h-full flex flex-col overflow-hidden',
      main: 'flex-1 min-h-0 relative overflow-hidden',
    };
  }

  return {
    root: 'min-h-dvh',
    sidebar: 'sticky top-0 h-dvh',
    content: 'min-h-dvh flex flex-col overflow-x-hidden',
    main: 'flex-1',
  };
}
