import type { LayoutBehavior } from '@/core/router/types';

export interface BehaviorStyles {
  root: string;
  sidebar: string;
  content: string;
  main: string;
}

export type { LayoutBehavior };
