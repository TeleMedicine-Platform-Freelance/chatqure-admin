import React from 'react';
import AnimatedDropdown from '@/shared/ui/components/animated-dropdown/AnimatedDropdown';
import AnimatedDropdownTrigger from '@/shared/ui/components/animated-dropdown/AnimatedDropdownTrigger';
import AnimatedDropdownContent from '@/shared/ui/components/animated-dropdown/AnimatedDropdownContent';
import { Bell, Reply, Eye } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { FloatingHover, useHoverBackground } from '@/shared/ui/components/FloatingHover';
import { Tabs, TabsList, TabsTrigger } from '@/shared/ui/primitives/tabs';
import { items as mockItems } from '@/mocks/data/notifications';
import type { NotificationItem } from '@/shared/domain/models/NotificationItem';

const TabDefs: Array<{ key: NotificationItem['type']; label: string }> = [
  { key: 'all', label: 'All' },
  { key: 'following', label: 'Following' },
  { key: 'archive', label: 'Archive' },
];

const NotificationsMenu: React.FC = () => {
  const { t } = useTranslation('common');
  const [tab, setTab] = React.useState<NotificationItem['type']>('all');
  const containerRef = React.useRef<HTMLDivElement | null>(null);
  const { rect, bind, clear } = useHoverBackground<HTMLDivElement>(containerRef);

  const items = mockItems.filter((i) => tab === 'all' ? true : i.type === tab);

  return (
    <AnimatedDropdown placement="bottom-end" openOn="hover">
      <AnimatedDropdownTrigger asChild>
        <button
          className="relative inline-flex size-9 items-center justify-center rounded-full hover:bg-gray-100 dark:hover:bg-neutral-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 border border-gray-200/70 dark:border-neutral-800"
          aria-label={t('topbar.notifications', { defaultValue: 'Notifications' })}
        >
          <Bell className="size-5" />
          <span className="absolute -top-0.5 -right-0.5 inline-flex size-2 rounded-full bg-red-500" />
        </button>
      </AnimatedDropdownTrigger>
      <AnimatedDropdownContent className="z-[60] w-[420px]">
        <div className="px-3 pt-2 pb-1 text-base font-semibold">{t('topbar.notificationsTitle', { defaultValue: 'Notifications' })}</div>
        <Tabs value={tab} onValueChange={(v) => setTab(v as NotificationItem['type'])} className="px-2 pb-2">
          <TabsList>
            {TabDefs.map(tb => (
              <TabsTrigger key={tb.key} value={tb.key}>
                {t(`topbar.tab.${tb.key}`, { defaultValue: tb.label })}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
        <div ref={containerRef} className="relative max-h-[320px] overflow-y-auto px-1 py-2" onMouseLeave={clear}>
          <FloatingHover rect={rect} />
          {items.map((it) => (
            <div key={it.id} className="relative p-3 flex gap-3 items-start rounded-xl focus-within:ring-2 focus-within:ring-blue-500" {...bind}>
              <div className="shrink-0 rounded-full bg-gray-200 dark:bg-neutral-700 size-8" />
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{it.title}</div>
                <div className="text-xs text-gray-500 dark:text-gray-400">{it.time}</div>
              </div>
              <div className="flex gap-1">
                <button className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs bg-gray-100 dark:bg-neutral-800">
                  <Reply className="size-3.5" />
                  {t('topbar.reply', { defaultValue: 'Reply' })}
                </button>
                <button className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs bg-gray-100 dark:bg-neutral-800">
                  <Eye className="size-3.5" />
                  {t('topbar.view', { defaultValue: 'View' })}
                </button>
              </div>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between gap-2 px-2 pt-2">
          <button className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-neutral-800 text-sm">{t('topbar.markAllRead', { defaultValue: 'Mark all as read' })}</button>
          <button className="px-3 py-2 rounded-xl bg-blue-600 text-white text-sm">{t('topbar.viewAll', { defaultValue: 'View all notifications' })}</button>
        </div>
      </AnimatedDropdownContent>
    </AnimatedDropdown>
  );
};

export default NotificationsMenu;
