import React from 'react';
import { Menu } from 'lucide-react';
import { useLayout } from '@/shared/ui/layouts/hooks/useLayout';
import { useTranslation } from 'react-i18next';
import LanguageMenu from '@/shared/ui/layouts/vertical/topbar/LanguageMenu';
import NotificationsMenu from '@/shared/ui/layouts/vertical/topbar/NotificationsMenu';
import AvatarMenu from '@/shared/ui/layouts/vertical/topbar/AvatarMenu';
import { GlobalCommandPalette } from '@/shared/ui/layouts/vertical/topbar/GlobalCommandPalette';

const TopBar: React.FC = () => {
  const { setMobileOpen } = useLayout();
  const { t } = useTranslation('common');

  return (
    <header className="sticky top-0 z-10 bg-transparent">
      <div className="p-4">
        <div className="flex items-center gap-3 rounded-xl bg-white dark:bg-neutral-900 shadow-sm border border-gray-100 dark:border-neutral-800 px-3 py-2">
          {/* Mobile menu */}
          <button
            className="md:hidden inline-flex size-9 items-center justify-center rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            aria-label={t('topbar.openMenu', { defaultValue: 'Open menu' })}
            onClick={() => setMobileOpen(true)}
          >
            <Menu className="size-5" />
          </button>

          {/* Global Command Palette */}
          <GlobalCommandPalette />

          {/* Right actions */}
          <div className="relative flex items-center gap-2">
            <LanguageMenu />
            <NotificationsMenu />
            <AvatarMenu />
          </div>
        </div>
      </div>
    </header>
  );
};

export default TopBar;
