/**
 * @file AppLayout.tsx - Layout Resolver
 * 
 * Resolves and renders the appropriate layout implementation based on:
 * - layoutMode (user setting): vertical-boxed, vertical-double-sidebar, etc.
 * - layoutBehavior (route metadata): default or fixed-height
 * 
 * This component acts as a resolver, not a layout implementation.
 * All layout implementations are in families/{family}/variants/{variant} folders.
 */
import React from 'react';
import { LayoutProvider } from '../context/LayoutContext';
import { useLayout } from '../hooks/useLayout';
import { VerticalBoxedLayout } from '../families/vertical/variants/boxed/VerticalBoxedLayout';
import { VerticalDoubleSidebarLayout } from '../families/vertical/variants/double-sidebar/VerticalDoubleSidebarLayout';
import { VerticalEdgeLayout } from '../families/vertical/variants/edge/VerticalEdgeLayout';

const LayoutResolver: React.FC = () => {
  const { layoutMode, layoutBehavior } = useLayout();

  switch (layoutMode) {
    case 'vertical':
    case 'vertical-boxed':
      return <VerticalBoxedLayout behavior={layoutBehavior} />;
    
    case 'vertical-double-sidebar':
      return <VerticalDoubleSidebarLayout behavior={layoutBehavior} />;
    
    case 'vertical-edge':
      return <VerticalEdgeLayout behavior={layoutBehavior} />;
    
    case 'horizontal':
    case 'horizontal-centered':
      return <VerticalBoxedLayout behavior={layoutBehavior} />;
    
    default:
      return <VerticalBoxedLayout behavior={layoutBehavior} />;
  }
};

const AppLayout: React.FC = () => {
  return (
    <LayoutProvider>
      <LayoutResolver />
    </LayoutProvider>
  );
};

export default AppLayout;
