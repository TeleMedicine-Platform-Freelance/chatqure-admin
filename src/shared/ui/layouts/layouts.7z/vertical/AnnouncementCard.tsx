import React from 'react';
import { X, Play } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const STORAGE_KEY = 'katalyst_announcement_dismissed';

const AnnouncementCard: React.FC = () => {
  const [dismissed, setDismissed] = React.useState<boolean>(false);
  const [leaving, setLeaving] = React.useState<boolean>(false);
  const { t } = useTranslation('sidebar');

  React.useEffect(() => {
    setDismissed(localStorage.getItem(STORAGE_KEY) === 'true');
  }, []);

  const onDismiss = () => {
    setLeaving(true);
    window.setTimeout(() => {
      setDismissed(true);
      localStorage.setItem(STORAGE_KEY, 'true');
    }, 220);
  };

  if (dismissed) return null;

  return (
    <div className={["relative rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-neutral-700 bg-slate-50 dark:bg-slate-800 transition-all duration-300",
      leaving ? 'opacity-0 scale-95' : 'opacity-100 scale-100'].join(' ')}>
      <button aria-label={t('announcement.dismiss', 'Dismiss')} onClick={onDismiss} className="absolute right-2 top-2 inline-flex size-6 items-center justify-center rounded hover:bg-gray-100 dark:hover:bg-neutral-700">
        <X className="size-4" />
      </button>
      <div className="flex flex-col items-center text-center space-y-2">
        <div className="size-8 rounded-full bg-gradient-to-br from-indigo-400 to-indigo-600" />
        <div className="font-semibold">{t('announcement.title', 'Introducing Company AI')}</div>
        <p className="text-sm text-gray-600 dark:text-gray-300">{t('announcement.desc', 'AI is mature enough to add value to most industries.')}</p>
        <button className="inline-flex items-center gap-2 rounded-xl bg-blue-600 text-white px-3 py-2 text-sm hover:bg-blue-700">
          <Play className="size-4" />
          {t('announcement.cta', 'Watch 1 min demo')}
        </button>
      </div>
    </div>
  );
};

export default AnnouncementCard;
