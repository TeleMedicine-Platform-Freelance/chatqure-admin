import { useState, useEffect, useRef } from 'react';
import SidebarHeader from '@/shared/ui/layouts/vertical/sidebar/SidebarHeader';
import SidebarGroup from '@/shared/ui/layouts/vertical/sidebar/SidebarGroup';
import SidebarItem from '@/shared/ui/layouts/vertical/sidebar/SidebarItem';
import SidebarStepperGroup from '@/shared/ui/layouts/vertical/sidebar/SidebarStepperGroup';
import FavoriteApps from '@/shared/ui/layouts/vertical/FavoriteApps';
import AnnouncementCard from '@/shared/ui/layouts/vertical/AnnouncementCard';
import SidebarThemeToggler from '@/shared/ui/layouts/vertical/sidebar/SidebarThemeToggler';
import { useLayout } from '@/shared/ui/layouts/hooks/useLayout';
import { sidebarSections } from '@/app/config/navigation';
import {
  Home, LayoutDashboard, BarChart2, PieChart, Calendar, Mail, MessageCircle,
  Kanban, FileText, Users, Settings, Plug, Bell, Palette, Type, Component,
  Table, LayoutGrid, Layers, AlertTriangle, Sparkles, Zap, Command, Badge,
  Keyboard, Lock, ShieldCheck, BookOpen, Loader, Search, Columns, GitCommit
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import SimpleBar from 'simplebar-react';
import { cn } from '@/lib/utils';
import logo from '@/assets/logo.png';
import type { SidebarIconKey } from '@/app/config/navigation';

const iconMap: Record<SidebarIconKey, React.ComponentType<{ className?: string }>> = {
  'home': Home,
  'layout-dashboard': LayoutDashboard,
  'bar-chart': BarChart2,
  'pie-chart': PieChart,
  'calendar': Calendar,
  'mail': Mail,
  'message-circle': MessageCircle,
  'kanban': Kanban,
  'file-text': FileText,
  'users': Users,
  'settings': Settings,
  'plug': Plug,
  'bell': Bell,
  'palette': Palette,
  'type': Type,
  'component': Component,
  'table': Table,
  'layout-grid': LayoutGrid,
  'layers': Layers,
  'alert-triangle': AlertTriangle,
  'sparkles': Sparkles,
  'zap': Zap,
  'command': Command,
  'badge': Badge,
  'keyboard': Keyboard,
  'lock': Lock,
  'shield-check': ShieldCheck,
  'book-open': BookOpen,
  'loader': Loader,
  'search': Search,
  'columns': Columns,
  'git-commit': GitCommit,
};

interface SidebarProps {
  onItemClick?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onItemClick }) => {
  const { collapsed } = useLayout();
  const simplebarRef = useRef(null);

  const { t } = useTranslation('sidebar');

  const [expandedMap, setExpandedMap] = useState<Record<string, boolean>>({});

  // Auto-close any open subnavs when collapsed
  useEffect(() => {
    if (!collapsed) return;
    const timeoutId = window.setTimeout(() => setExpandedMap({}), 0);
    return () => window.clearTimeout(timeoutId);
  }, [collapsed]);

  return (
    <div className="h-full">
      <div className={
        cn("h-full rounded-xl bg-white dark:bg-neutral-900 text-sidebar-foreground shadow-sm border px-3 py-3 space-y-4 flex flex-col transition-[width] duration-300 ease-in-out",
        collapsed ? 'w-[4.5rem]' : 'w-72')
      }>
        <div className="px-1 pb-2 ">
          <SidebarHeader title={t('brand')} logo={<img src={logo} alt={t('brand')} className="size-8 rounded-full" />} />
        </div>

        <nav aria-label={t('ariaMainNav')} className="flex-1 min-h-0">
          <SimpleBar ref={simplebarRef} className="h-full">
            <div className="space-y-6">
              {sidebarSections.map((section) => (
                <SidebarGroup key={section.id} title={collapsed ? undefined : t(`section.${section.id}`)}>
                  {section.items.map((item) => {
                    const Icon = item.icon ? iconMap[item.icon] : null;
                    const expanded = !!expandedMap[item.id];
                    const setExpanded = (v: boolean) => setExpandedMap(prev => ({ ...prev, [item.id]: v }));
                    const target = item.target;

                    if (item.children && item.children.length > 0) {
                      const controlsId = `stepper-${item.id}`;
                      return (
                        <div key={item.id}>
                          <SidebarItem
                            icon={Icon}
                            label={t(`item.${item.id}`)}
                            collapsible
                            expanded={expanded}
                            onToggle={() => setExpanded(!expanded)}
                            onClick={() => setExpanded(!expanded)}
                            ariaControls={controlsId}
                            data-sidebar-item={item.id}
                          />
                          <div
                            id={controlsId}
                            className={cn(
                              'overflow-hidden transition-all duration-300 ease-in-out',
                              expanded ? 'max-h-64 opacity-100' : 'max-h-0 opacity-0'
                            )}
                          >
                            <SidebarStepperGroup
                              items={item.children.map((s) => ({
                                to: s.to ?? '#',
                                label: t(`steps.${item.id}.${s.id}`)
                              }))}
                              target={target}
                              rel={target ? 'noopener noreferrer' : undefined}
                              onNavigate={onItemClick}
                            />
                          </div>
                        </div>
                      );
                    }

                    // Items with steps are handled in the 'settings' block above
                    return (
                      <SidebarItem
                        key={item.id}
                        icon={Icon}
                        label={t(`item.${item.id}`)}
                        to={item.to}
                        target={item.target}
                        rel={item.target ? 'noopener noreferrer' : undefined}
                        badge={item.badge ? (item.badge.type === 'count' ? { type: 'count', value: item.badge.value ?? 0 } : { type: 'dot', color: item.badge.color }) : undefined}
                        onClick={onItemClick}
                        data-sidebar-item={item.id}
                      />
                    );
                  })}
                </SidebarGroup>
              ))}

              {!collapsed && (
                <div className="space-y-3">
                  <FavoriteApps />
                </div>
              )}
            </div>
          </SimpleBar>
        </nav>

        {/* Footer */}
        <div className="space-y-3 mx-auto">
          {!collapsed && <AnnouncementCard />}
          <SidebarThemeToggler size="sm" />
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
