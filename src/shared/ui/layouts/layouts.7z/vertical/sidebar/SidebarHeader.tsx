import React from 'react';
import { useLayout } from '@/shared/ui/layouts/hooks/useLayout';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { cn } from '@/lib/utils';

interface Props {
  title?: string;
  logo?: React.ReactNode;
}

const SidebarHeader: React.FC<Props> = ({ title = 'Katalyst', logo }) => {
  const { collapsed, toggleCollapsed: toggle } = useLayout();
  const { t } = useTranslation('sidebar');
  const LogoElement = logo;

  return (
    <div className="flex items-center justify-between gap-2">
      <div className="flex items-center gap-3">
        {LogoElement ?? (
          LogoElement
        )}
        {!collapsed && (
          <span className="font-semibold tracking-tight">{title}</span>
        )}
      </div>

      <button
        aria-label={collapsed ? t('expand') : t('collapse')}
        onClick={toggle}
        className={cn(
          "inline-flex items-center justify-center size-7 rounded-full hover:bg-gray-100 dark:hover:bg-neutral-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 cursor-pointer",
          collapsed && 'bg-gray-100 dark:bg-neutral-600 hover:bg-gray-200 dark:hover:bg-neutral-700 absolute right-0' 
        )}
      >
        {collapsed ? (
          <ChevronRight className="size-4" />
        ) : (
          <ChevronLeft className="size-4" />
        )}
      </button>
    </div>
  );
};

export default SidebarHeader;
