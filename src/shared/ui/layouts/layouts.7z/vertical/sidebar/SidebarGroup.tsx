import React from 'react';

interface SidebarGroupProps {
  title?: string;
  children: React.ReactNode;
}

const SidebarGroup: React.FC<SidebarGroupProps> = ({ title, children }) => {
  return (
    <div className="space-y-2">
      {title && (
        <div className="px-2 text-xs font-medium text-gray-500 dark:text-gray-400">{title}</div>
      )}
      <div className="space-y-1">
        {children}
      </div>
    </div>
  );
};

export default SidebarGroup;
