import { cn } from '@/lib/utils';
import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';

export interface StepItem {
  label: string;
  to: string;
}

interface SidebarStepperGroupProps {
  items: StepItem[];
  onNavigate?: () => void;
  target?: React.HTMLAttributeAnchorTarget;
  rel?: string;
}

const SidebarStepperGroup: React.FC<SidebarStepperGroupProps> = ({ items, onNavigate, target, rel }) => {
  const { pathname } = useLocation();

  return (
    <div className="pl-4">
      <div className="space-y-1 ml-4 py-2">
        {items.map((item) => {
          const active = pathname === item.to;

          return (
            <div key={item.to} className="flex items-center gap-3 py-1 px-1 rounded-xl group">
              <span className={cn(
                'inline-flex items-center justify-center size-2.5 rounded-full relative transition-all duration-300',
                'after:content-[""] after:absolute after:inset-0 after:bg-gray-200 dark:after:bg-neutral-700 after:w-[1px] after:top-full after:left-[calc(50%-1px)] after:z-10 after:translate-y-1/2 after:h-full',
                'group-last-of-type:after:hidden',
                'group-hover:bg-blue-600 dark:group-hover:bg-gray-300',
                active ? 'bg-blue-600 ring-4 ring-blue-100 dark:ring-gray-950/40 dark:bg-gray-300' : 'bg-gray-400 dark:bg-gray-500'
              )} />

              <NavLink
                to={item.to}
                onClick={onNavigate}
                target={target}
                rel={rel}
                aria-current={active ? 'page' : undefined}
                className={cn(
                  'text-sm',
                  'group-hover:text-blue-600 dark:group-hover:text-gray-300',
                  active ? 'text-blue-600 dark:text-gray-300 font-medium' : 'text-gray-600 dark:text-gray-500'
                )}
              >
                {item.label}
              </NavLink>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SidebarStepperGroup;
