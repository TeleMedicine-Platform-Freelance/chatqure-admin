import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/shared/ui/primitives/tooltip';
import type { LucideIcon } from 'lucide-react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { useLayout } from '@/shared/ui/layouts/hooks/useLayout';
import { useTranslation } from 'react-i18next';

export type Badge =
  | { type: 'count'; value: number }
  | { type: 'dot'; color?: string };

export interface SidebarItemProps {
  icon?: LucideIcon | React.ComponentType<{ className?: string }> | null;
  label: string;
  to?: string;
  target?: React.HTMLAttributeAnchorTarget;
  rel?: string;
  onClick?: () => void;
  badge?: Badge;
  collapsible?: boolean;
  expanded?: boolean;
  onToggle?: () => void;
  ariaControls?: string;
  /** Data attribute for tour targeting */
  'data-sidebar-item'?: string;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon: IconProp, label, to, target, rel, onClick, badge, collapsible, expanded, onToggle, ariaControls, 'data-sidebar-item': dataSidebarItem }) => {
  const Icon = IconProp ?? null;
  const { pathname } = useLocation();
  const { collapsed } = useLayout();
  const { t } = useTranslation('sidebar');

  const isExternal = !!to && (to.startsWith('http://') || to.startsWith('https://'));
  const safeRel = target === '_blank' ? (rel ?? 'noopener noreferrer') : rel;

  const content = (
    <div className={[
      'group flex items-center rounded-xl py-2 hover:bg-gray-100 dark:hover:bg-neutral-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 transition-all duration-300 ease-in-out w-full',
      collapsed ? 'justify-center gap-0 px-0' : 'gap-3 px-2'
    ].join(' ')}>
      <div className="relative">
        {Icon && <Icon className="size-5" />}
        {/* badge dot overlay in collapsed */}
        {collapsed && badge && badge.type === 'dot' && (
          <span className="absolute -top-0.5 -right-0.5 inline-block size-[6px] rounded-full bg-blue-500" />
        )}
        {collapsed && badge && badge.type === 'count' && (
          <span className="absolute -top-0.5 -right-0.5 inline-block size-[6px] rounded-full bg-blue-500" />
        )}
      </div>

      <div className={["flex items-center gap-2 min-w-0 transition-all duration-300",
        collapsed ? 'opacity-0 w-0 overflow-hidden pointer-events-none' : 'flex-1 opacity-100 w-auto'].join(' ')}>
        <span className="text-sm text-start font-medium flex-1 truncate transition-all duration-300">{label}</span>
        
        {badge?.type === 'count' && (
          <span className="ml-auto inline-flex min-w-[1.25rem] items-center justify-center rounded-full bg-gray-200 dark:bg-neutral-700 text-[11px] font-semibold px-1.5 py-0.5">{badge.value}</span>
        )}

        {badge?.type === 'dot' && (
          <span className="ml-auto inline-block size-2 rounded-full bg-blue-500" />
        )}
        
        {collapsible && (
          <span
            className="ml-1 inline-flex size-5 items-center justify-center rounded hover:bg-gray-200 dark:hover:bg-neutral-700"
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); onToggle?.(); }}
            role="button"
            aria-label={expanded ? t('collapse', 'Collapse') : t('expand', 'Expand')}
          >
            {expanded ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
          </span>
        )}
      </div>
    </div>
  );

  // Use startsWith for routes with nested paths (e.g., /apps/chat/*)
  const isActive = !isExternal && to ? (pathname === to || pathname.startsWith(`${to}/`)) : false;

  const wrapperClass = [
    'block rounded-xl transition-colors w-full',
    isActive ? 'bg-blue-100 dark:bg-blue-800/20 text-blue-700 dark:text-blue-300 font-medium' : 'text-gray-700 dark:text-gray-200',
  ].join(' ');

  const node = to ? (
    isExternal ? (
      <a href={to} onClick={onClick} target={target} rel={safeRel} className={wrapperClass} data-sidebar-item={dataSidebarItem}>
        {content}
      </a>
    ) : (
      <NavLink to={to} onClick={onClick} target={target} rel={safeRel} aria-current={isActive ? 'page' : undefined} className={wrapperClass} data-sidebar-item={dataSidebarItem}>
        {content}
      </NavLink>
    )
  ) : (
    <button onClick={onClick} className={wrapperClass} aria-expanded={collapsible ? (collapsed ? false : expanded) : undefined} aria-controls={collapsible ? ariaControls : undefined} data-sidebar-item={dataSidebarItem}>
      {content}
    </button>
  );

  if (!collapsed) return node;

  return (
    <Tooltip>
      <TooltipTrigger asChild>{node}</TooltipTrigger>
      <TooltipContent side="right" sideOffset={10} className="rounded-md text-xs px-2 py-1">
        {label}
      </TooltipContent>
    </Tooltip>
  );
};

export default SidebarItem;
