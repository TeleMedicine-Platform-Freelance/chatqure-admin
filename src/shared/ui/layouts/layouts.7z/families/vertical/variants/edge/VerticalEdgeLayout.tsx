import React from 'react';
import { Outlet } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useLayout } from '@/shared/ui/layouts/hooks/useLayout';
import { VerticalShell } from '../../components/shell/VerticalShell';
import Sidebar from '../../components/sidebar/Sidebar';
import TopBar from '../../components/topbar/TopBar';
import type { LayoutBehavior } from '@/core/router/types';

interface VerticalEdgeLayoutProps {
  behavior: LayoutBehavior;
}

/**
 * VerticalEdgeLayout - Edge-to-edge layout with full-height sidebar
 * 
 * Behavior:
 * - Edge-to-edge (no outer margins)
 * - Full-height sidebar with gradient/solid background
 * - Light theme: Dark sidebar, light content
 * - Dark theme: Lighter sidebar than content
 * - Compact mode: Icon-only sidebar (w-16)
 * - Expanded mode: Full sidebar with labels (w-64)
 * - Supports both default and fixed-height behaviors
 */
export const VerticalEdgeLayout: React.FC<VerticalEdgeLayoutProps> = ({ behavior }) => {
  const { collapsed, mobileOpen, setMobileOpen } = useLayout();

  const isFixedHeight = behavior === 'fixed-height';

  return (
    <VerticalShell behavior={behavior} variant="edge">
      <div className={cn(
        'grid md:grid-cols-[auto_1fr]',
        isFixedHeight && 'h-full'
      )}>
        {/* Sidebar - Full height with gradient/solid background */}
        <aside className={cn(
          'hidden md:flex flex-col',
          collapsed ? 'w-16' : 'w-64',
          'h-dvh',
          'bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900',
          'dark:from-slate-800 dark:via-slate-700 dark:to-slate-800',
          'border-r border-slate-700/50 dark:border-slate-600/50',
          'transition-all duration-300 ease-in-out'
        )}>
          <Sidebar compact={collapsed} />
        </aside>

        {/* Content column */}
        <div className={cn(
          'flex flex-col min-w-0',
          isFixedHeight ? 'h-full overflow-hidden' : 'min-h-dvh overflow-x-hidden',
          'bg-gray-50 dark:bg-slate-900'
        )}>
          <TopBar />

          <main className={cn(
            'p-4',
            isFixedHeight
              ? 'flex-1 min-h-0 relative overflow-hidden'
              : 'flex-1'
          )}>
            <Outlet />
          </main>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            className="fixed inset-0 z-50 md:hidden"
            role="dialog"
            aria-modal="true"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <motion.div
              className="absolute inset-0 bg-black/40"
              onClick={() => setMobileOpen(false)}
              initial={{ opacity: 0, filter: 'blur(0px)' }}
              animate={{ opacity: 1, filter: 'blur(6px)' }}
              exit={{ opacity: 0, filter: 'blur(0px)' }}
              transition={{ duration: 0.25 }}
            />

            <motion.div
              className="absolute left-0 top-0 h-full"
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', stiffness: 380, damping: 38 }}
            >
              <div className="h-full w-64 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 p-3">
                <Sidebar compact={false} onItemClick={() => setMobileOpen(false)} />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </VerticalShell>
  );
};
