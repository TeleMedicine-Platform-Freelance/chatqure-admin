import React from 'react';
import { Outlet } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useLayout } from '@/shared/ui/layouts/hooks/useLayout';
import { VerticalShell } from '../../components/shell/VerticalShell';
import IconRail from '../../components/sidebar/IconRail';
import SecondarySidebar from '../../components/sidebar/SecondarySidebar';
import TopBar from '../../components/topbar/TopBar';
import type { LayoutBehavior } from '@/core/router/types';

interface VerticalDoubleSidebarLayoutProps {
  behavior: LayoutBehavior;
}

/**
 * VerticalDoubleSidebarLayout - Icon rail + secondary sidebar
 * 
 * Behavior:
 * - IconRail (primary) ALWAYS visible (16 cols)
 * - SecondarySidebar shows detailed navigation
 * - Compact mode (collapsed=true) hides ONLY SecondarySidebar
 * - IconRail remains visible in compact mode
 * - Supports both default and fixed-height behaviors
 */
export const VerticalDoubleSidebarLayout: React.FC<VerticalDoubleSidebarLayoutProps> = ({ behavior }) => {
  const { collapsed } = useLayout();

  const isFixedHeight = behavior === 'fixed-height';

  return (
    <VerticalShell behavior={behavior} variant="double-sidebar">
      <div className={cn(
        'grid',
        collapsed ? 'md:grid-cols-[4rem_1fr]' : 'md:grid-cols-[4rem_16rem_1fr]',
        isFixedHeight && 'h-full',
        'transition-all duration-300 ease-in-out'
      )}>
        {/* Icon Rail - ALWAYS VISIBLE */}
        <aside className={cn(
          'hidden md:block',
          isFixedHeight ? 'h-full overflow-hidden' : 'sticky top-0 h-dvh'
        )}>
          <IconRail />
        </aside>

        {/* Secondary Sidebar - HIDDEN IN COMPACT MODE */}
        {!collapsed && (
          <aside className={cn(
            'hidden md:block',
            isFixedHeight ? 'h-full overflow-hidden' : 'sticky top-0 h-dvh'
          )}>
            <SecondarySidebar />
          </aside>
        )}

        {/* Content column */}
        <div className={cn(
          'flex flex-col min-w-0',
          isFixedHeight ? 'h-full overflow-hidden' : 'min-h-dvh overflow-x-hidden'
        )}>
          <TopBar />

          <main className={cn(
            'p-4',
            isFixedHeight
              ? 'flex-1 min-h-0 relative overflow-hidden'
              : 'flex-1'
          )}>
            <Outlet />
          </main>
        </div>
      </div>
    </VerticalShell>
  );
};
