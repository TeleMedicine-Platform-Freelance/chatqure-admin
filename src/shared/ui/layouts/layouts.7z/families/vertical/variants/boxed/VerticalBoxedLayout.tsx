import React from 'react';
import { Outlet } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useLayout } from '@/shared/ui/layouts/hooks/useLayout';
import { VerticalShell } from '../../components/shell/VerticalShell';
import Sidebar from '../../components/sidebar/Sidebar';
import TopBar from '../../components/topbar/TopBar';
import type { LayoutBehavior } from '@/core/router/types';

interface VerticalBoxedLayoutProps {
  behavior: LayoutBehavior;
}

/**
 * VerticalBoxedLayout - Single sidebar with boxed containers
 * 
 * Behavior:
 * - Single sidebar on left
 * - Collapses to icon-only in compact mode (collapsed=true)
 * - Boxed containers with rounded corners
 * - Supports both default and fixed-height behaviors
 */
export const VerticalBoxedLayout: React.FC<VerticalBoxedLayoutProps> = ({ behavior }) => {
  const { collapsed, mobileOpen, setMobileOpen } = useLayout();

  const isFixedHeight = behavior === 'fixed-height';

  return (
    <VerticalShell behavior={behavior} variant="boxed">
      <div className={cn(
        'grid md:grid-cols-[auto_1fr]',
        isFixedHeight && 'h-full'
      )}>
        {/* Sidebar (desktop) */}
        <aside className={cn(
          'hidden md:block px-3 py-4',
          collapsed ? 'w-20' : 'w-72',
          isFixedHeight ? 'h-full overflow-hidden' : 'sticky top-0 h-dvh',
          'transition-all duration-300 ease-in-out'
        )}>
          <Sidebar compact={collapsed} />
        </aside>

        {/* Content column */}
        <div className={cn(
          'flex flex-col min-w-0',
          isFixedHeight ? 'h-full overflow-hidden' : 'min-h-dvh overflow-x-hidden'
        )}>
          <TopBar />

          <main className={cn(
            'p-4',
            isFixedHeight
              ? 'flex-1 min-h-0 relative overflow-hidden'
              : 'flex-1'
          )}>
            <Outlet />
          </main>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            className="fixed inset-0 z-50 md:hidden"
            role="dialog"
            aria-modal="true"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <motion.div
              className="absolute inset-0 bg-black/40"
              onClick={() => setMobileOpen(false)}
              initial={{ opacity: 0, filter: 'blur(0px)' }}
              animate={{ opacity: 1, filter: 'blur(6px)' }}
              exit={{ opacity: 0, filter: 'blur(0px)' }}
              transition={{ duration: 0.25 }}
            />

            <motion.div
              className="absolute left-0 top-0 h-full p-3"
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', stiffness: 380, damping: 38 }}
            >
              <Sidebar compact={false} onItemClick={() => setMobileOpen(false)} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </VerticalShell>
  );
};
