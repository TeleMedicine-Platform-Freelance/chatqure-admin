import React from 'react';
import { cn } from '@/lib/utils';
import { applyLayoutBehavior } from '@/shared/ui/layouts/behaviors/applyLayoutBehavior';
import type { LayoutBehavior } from '@/core/router/types';

interface VerticalShellProps {
  behavior: LayoutBehavior;
  variant: 'boxed' | 'double-sidebar' | 'edge';
  children: React.ReactNode;
}

/**
 * VerticalShell - Base shell for vertical layout family
 * 
 * Responsibilities:
 * - Apply behavior-specific styles (default vs fixed-height)
 * - Provide base grid structure
 * - Apply variant-specific spacing/containers
 * 
 * Does NOT:
 * - Render sidebar/topbar (variants do this)
 * - Manage layout state (LayoutProvider does this)
 */
export const VerticalShell: React.FC<VerticalShellProps> = ({ behavior, variant, children }) => {
  const styles = applyLayoutBehavior(behavior);

  const containerClasses = variant === 'boxed'
    ? ''
    : '';

  return (
    <div className={cn(styles.root, containerClasses)}>
      {children}
    </div>
  );
};
