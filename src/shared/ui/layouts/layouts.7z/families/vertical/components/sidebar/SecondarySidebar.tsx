import React, { useState, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import SidebarGroup from '@/shared/ui/layouts/vertical/sidebar/SidebarGroup';
import SidebarItem from '@/shared/ui/layouts/vertical/sidebar/SidebarItem';
import SidebarStepperGroup from '@/shared/ui/layouts/vertical/sidebar/SidebarStepperGroup';
import { sidebarSections, type SidebarIconKey } from '@/app/config/navigation';
import {
  Home, LayoutDashboard, BarChart2, PieChart, Calendar, Mail, MessageCircle,
  Kanban, FileText, Users, Settings, Plug, Bell, Palette, Type, Component,
  Table, LayoutGrid, Layers, AlertTriangle, Sparkles, Zap, Command, Badge,
  Keyboard, Lock, ShieldCheck, BookOpen, Loader, Search, Columns, GitCommit
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import SimpleBar from 'simplebar-react';
import { cn } from '@/lib/utils';

const iconMap: Record<SidebarIconKey, React.ComponentType<{ className?: string }>> = {
  'home': Home,
  'layout-dashboard': LayoutDashboard,
  'bar-chart': BarChart2,
  'pie-chart': PieChart,
  'calendar': Calendar,
  'mail': Mail,
  'message-circle': MessageCircle,
  'kanban': Kanban,
  'file-text': FileText,
  'users': Users,
  'settings': Settings,
  'plug': Plug,
  'bell': Bell,
  'palette': Palette,
  'type': Type,
  'component': Component,
  'table': Table,
  'layout-grid': LayoutGrid,
  'layers': Layers,
  'alert-triangle': AlertTriangle,
  'sparkles': Sparkles,
  'zap': Zap,
  'command': Command,
  'badge': Badge,
  'keyboard': Keyboard,
  'lock': Lock,
  'shield-check': ShieldCheck,
  'book-open': BookOpen,
  'loader': Loader,
  'search': Search,
  'columns': Columns,
  'git-commit': GitCommit,
};

interface SecondarySidebarProps {
  onItemClick?: () => void;
}

/**
 * SecondarySidebar - Detailed navigation for double sidebar layout
 * 
 * Shows full navigation with labels and sub-items
 * Hidden in compact mode, IconRail remains visible
 */
const SecondarySidebar: React.FC<SecondarySidebarProps> = ({ onItemClick }) => {
  const { pathname } = useLocation();
  const simplebarRef = useRef(null);
  const { t } = useTranslation('sidebar');

  const [expandedMap, setExpandedMap] = useState<Record<string, boolean>>({});

  const currentSection = sidebarSections.find(section =>
    section.items.some(item => item.to && pathname.startsWith(item.to))
  );

  const displaySections = currentSection ? [currentSection] : sidebarSections.slice(0, 2);

  return (
    <div className="h-full flex flex-col bg-white dark:bg-neutral-900 border-r border-gray-200 dark:border-neutral-800">
      <div className="p-4 border-b border-gray-200 dark:border-neutral-800">
        <h2 className="text-sm font-semibold text-gray-900 dark:text-gray-100">
          {currentSection ? t(`section.${currentSection.id}`) : t('section.home')}
        </h2>
      </div>

      <nav className="flex-1 min-h-0 p-3">
        <SimpleBar ref={simplebarRef} className="h-full">
          <div className="space-y-6">
            {displaySections.map((section) => (
              <SidebarGroup key={section.id} title={t(`section.${section.id}`)}>
                {section.items.map((item) => {
                  const Icon = item.icon ? iconMap[item.icon] : null;
                  const expanded = !!expandedMap[item.id];
                  const setExpanded = (v: boolean) => setExpandedMap(prev => ({ ...prev, [item.id]: v }));
                  const target = item.target;

                  if (item.children && item.children.length > 0) {
                    const controlsId = `stepper-${item.id}`;
                    return (
                      <div key={item.id}>
                        <SidebarItem
                          icon={Icon}
                          label={t(`item.${item.id}`)}
                          collapsible
                          expanded={expanded}
                          onToggle={() => setExpanded(!expanded)}
                          onClick={() => setExpanded(!expanded)}
                          ariaControls={controlsId}
                          data-sidebar-item={item.id}
                        />
                        <div
                          id={controlsId}
                          className={cn(
                            'overflow-hidden transition-all duration-300 ease-in-out',
                            expanded ? 'max-h-64 opacity-100' : 'max-h-0 opacity-0'
                          )}
                        >
                          <SidebarStepperGroup
                            items={item.children.map((s) => ({
                              to: s.to ?? '#',
                              label: t(`steps.${item.id}.${s.id}`)
                            }))}
                            target={target}
                            rel={target ? 'noopener noreferrer' : undefined}
                            onNavigate={onItemClick}
                          />
                        </div>
                      </div>
                    );
                  }

                  return (
                    <SidebarItem
                      key={item.id}
                      icon={Icon}
                      label={t(`item.${item.id}`)}
                      to={item.to}
                      target={item.target}
                      rel={item.target ? 'noopener noreferrer' : undefined}
                      badge={item.badge ? (item.badge.type === 'count' ? { type: 'count', value: item.badge.value ?? 0 } : { type: 'dot', color: item.badge.color }) : undefined}
                      onClick={onItemClick}
                      data-sidebar-item={item.id}
                    />
                  );
                })}
              </SidebarGroup>
            ))}
          </div>
        </SimpleBar>
      </nav>
    </div>
  );
};

export default SecondarySidebar;
