import React from 'react';
import { useLocation, NavLink } from 'react-router-dom';
import { sidebarSections, type SidebarIconKey } from '@/app/config/navigation';
import {
  Home, LayoutDashboard, BarChart2, PieChart, Calendar, Mail, MessageCircle,
  Kanban, FileText, Users, Settings, Plug, Bell, Palette, Type, Component,
  Table, LayoutGrid, Layers, AlertTriangle, Sparkles, Zap, Command, Badge,
  Keyboard, Lock, ShieldCheck, BookOpen, Loader, Search, Columns, GitCommit
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/shared/ui/primitives/tooltip';

const iconMap: Record<SidebarIconKey, React.ComponentType<{ className?: string }>> = {
  'home': Home,
  'layout-dashboard': LayoutDashboard,
  'bar-chart': BarChart2,
  'pie-chart': PieChart,
  'calendar': Calendar,
  'mail': Mail,
  'message-circle': MessageCircle,
  'kanban': Kanban,
  'file-text': FileText,
  'users': Users,
  'settings': Settings,
  'plug': Plug,
  'bell': Bell,
  'palette': Palette,
  'type': Type,
  'component': Component,
  'table': Table,
  'layout-grid': LayoutGrid,
  'layers': Layers,
  'alert-triangle': AlertTriangle,
  'sparkles': Sparkles,
  'zap': Zap,
  'command': Command,
  'badge': Badge,
  'keyboard': Keyboard,
  'lock': Lock,
  'shield-check': ShieldCheck,
  'book-open': BookOpen,
  'loader': Loader,
  'search': Search,
  'columns': Columns,
  'git-commit': GitCommit,
};

/**
 * IconRail - Always-visible icon navigation for double sidebar layout
 * 
 * Shows only primary navigation items as icons
 * Always visible, not affected by compact mode
 */
const IconRail: React.FC = () => {
  const { pathname } = useLocation();
  const { t } = useTranslation('sidebar');

  const primaryItems = sidebarSections
    .flatMap(section => section.items)
    .filter(item => item.navRole === 'primary' && item.to);

  return (
    <div className="h-full flex flex-col bg-white dark:bg-neutral-900 border-r border-gray-200 dark:border-neutral-800 py-4">
      <nav className="flex-1 flex flex-col items-center gap-2 px-2">
        {primaryItems.map((item) => {
          const Icon = item.icon ? iconMap[item.icon] : null;
          const isActive = item.to && pathname.startsWith(item.to);
          if (!Icon) return null;

          return (
            <Tooltip key={item.id}>
              <TooltipTrigger asChild>
                <NavLink
                  to={item.to!}
                  className={cn(
                    'flex items-center justify-center size-10 rounded-lg transition-colors',
                    'hover:bg-gray-100 dark:hover:bg-neutral-800',
                    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500',
                    isActive && 'bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400'
                  )}
                >
                  <Icon className="size-5" />
                </NavLink>
              </TooltipTrigger>
              <TooltipContent side="right">
                {t(`item.${item.id}`)}
              </TooltipContent>
            </Tooltip>
          );
        })}
      </nav>
    </div>
  );
};

export default IconRail;
