import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Outlet } from 'react-router-dom';
import { cn } from '@/lib/utils';
import Sidebar from '../vertical/sidebar/Sidebar';
import TopBar from '../vertical/topbar/TopBar';
import { useLayout } from '../hooks/useLayout';
import type { LayoutBehavior } from '@/core/router/types';

interface VerticalLayoutProps {
  behavior: LayoutBehavior;
}

const VerticalLayout: React.FC<VerticalLayoutProps> = ({ behavior }) => {
  const { mobileOpen, setMobileOpen } = useLayout();

  const isFixedHeight = behavior === 'fixed-height';

  return (
    <div
      className={cn(
        isFixedHeight ? 'h-dvh overflow-hidden' : 'min-h-dvh'
      )}
    >
      <div
        className={cn(
          'grid md:grid-cols-[auto_1fr]',
          isFixedHeight && 'h-full'
        )}
      >
        {/* Sidebar (desktop) */}
        <aside
          className={cn(
            'hidden md:block px-3 py-4',
            isFixedHeight ? 'h-full overflow-hidden' : 'sticky top-0 h-dvh'
          )}
        >
          <Sidebar />
        </aside>

        {/* Content column */}
        <div
          className={cn(
            'flex flex-col',
            isFixedHeight ? 'h-full overflow-hidden' : 'min-h-dvh overflow-x-hidden'
          )}
        >
          <TopBar />
          <main
            className={cn(
              'p-4',
              isFixedHeight
                ? 'flex-1 min-h-0 relative overflow-hidden'
                : 'flex-1'
            )}
          >
            <Outlet />
          </main>
        </div>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            className="fixed inset-0 z-50 md:hidden"
            role="dialog"
            aria-modal="true"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <motion.div
              className="absolute inset-0 bg-black/40"
              onClick={() => setMobileOpen(false)}
              initial={{ opacity: 0, filter: 'blur(0px)' }}
              animate={{ opacity: 1, filter: 'blur(6px)' }}
              exit={{ opacity: 0, filter: 'blur(0px)' }}
              transition={{ duration: 0.25 }}
            />

            <motion.div
              className="absolute left-0 top-0 h-full p-3"
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', stiffness: 380, damping: 38 }}
            >
              <Sidebar onItemClick={() => setMobileOpen(false)} />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default VerticalLayout;
