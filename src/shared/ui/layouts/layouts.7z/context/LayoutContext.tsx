import React, { createContext, useCallback, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { moduleRegistry } from '@/core/di/container';
import type { LayoutMode, LayoutBehavior } from '@/core/router/types';

export interface LayoutContextValue {
  layoutMode: LayoutMode;
  setLayoutMode: (mode: LayoutMode) => void;
  layoutBehavior: LayoutBehavior;
  collapsed: boolean;
  setCollapsed: (value: boolean) => void;
  toggleCollapsed: () => void;
  mobileOpen: boolean;
  setMobileOpen: (value: boolean) => void;
}

export const LayoutContext = createContext<LayoutContextValue | null>(null);

const LAYOUT_MODE_KEY = 'katalyst_layout_mode';
const COLLAPSE_KEY = 'katalyst_sidebar_collapsed';

interface LayoutProviderProps {
  children: React.ReactNode;
}

export const LayoutProvider: React.FC<LayoutProviderProps> = ({ children }) => {
  const location = useLocation();
  
  const [layoutMode, setLayoutModeState] = useState<LayoutMode>(() => {
    const stored = localStorage.getItem(LAYOUT_MODE_KEY);
    const validModes: LayoutMode[] = ['vertical', 'vertical-boxed', 'vertical-double-sidebar', 'vertical-edge', 'horizontal', 'horizontal-centered'];
    if (stored && validModes.includes(stored as LayoutMode)) {
      return stored as LayoutMode;
    }
    return 'vertical-boxed';
  });

  const [collapsed, setCollapsedState] = useState<boolean>(() => {
    const stored = localStorage.getItem(COLLAPSE_KEY);
    return stored === 'true';
  });

  const [mobileOpen, setMobileOpen] = useState<boolean>(false);

  const setLayoutMode = useCallback((mode: LayoutMode) => {
    setLayoutModeState(mode);
    localStorage.setItem(LAYOUT_MODE_KEY, mode);
  }, []);

  const setCollapsed = useCallback((value: boolean) => {
    setCollapsedState(value);
    localStorage.setItem(COLLAPSE_KEY, String(value));
  }, []);

  const toggleCollapsed = useCallback(() => {
    setCollapsed(!collapsed);
  }, [collapsed, setCollapsed]);

  const layoutBehavior = useMemo<LayoutBehavior>(() => {
    const allRoutes = moduleRegistry.getAllRoutes();
    const currentRoute = allRoutes.find(route => {
      const routePath = route.path.replace(/\/\*$/, '');
      return location.pathname.startsWith(routePath);
    });
    
    return currentRoute?.layoutBehavior ?? 'default';
  }, [location.pathname]);

  const value = useMemo<LayoutContextValue>(
    () => ({
      layoutMode,
      setLayoutMode,
      layoutBehavior,
      collapsed,
      setCollapsed,
      toggleCollapsed,
      mobileOpen,
      setMobileOpen,
    }),
    [layoutMode, setLayoutMode, layoutBehavior, collapsed, setCollapsed, toggleCollapsed, mobileOpen]
  );

  return <LayoutContext.Provider value={value}>{children}</LayoutContext.Provider>;
};
