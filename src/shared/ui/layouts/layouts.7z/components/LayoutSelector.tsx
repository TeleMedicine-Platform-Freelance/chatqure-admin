import React from 'react';
import { useTranslation } from 'react-i18next';
import { useLayout } from '@/shared/ui/layouts/hooks/useLayout';
import { layoutRegistry } from '@/shared/ui/layouts/registry/layoutRegistry';
import { LayoutPreviewCard } from './LayoutPreviewCard';

/**
 * LayoutSelector - Layout preview matrix for Settings panel
 * 
 * Displays all available layouts as preview cards
 * Allows instant layout switching with persistence
 */
export const LayoutSelector: React.FC = () => {
  const { t } = useTranslation('layouts');
  const { layoutMode, setLayoutMode } = useLayout();

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
          {t('selector.title', { defaultValue: 'Layout Style' })}
        </h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
          {t('selector.description', { defaultValue: 'Choose your preferred layout style. Changes apply instantly.' })}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {layoutRegistry.map((layout) => (
          <LayoutPreviewCard
            key={layout.id}
            active={layoutMode === layout.id}
            image={layout.previewImage}
            title={t(layout.titleKey)}
            description={t(layout.descriptionKey)}
            onClick={() => setLayoutMode(layout.id)}
            fallbackVariant={layout.variant}
          />
        ))}
      </div>

      <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
        <p className="text-sm text-blue-900 dark:text-blue-100">
          <strong>{t('selector.tip', { defaultValue: 'Tip:' })}</strong>{' '}
          {t('selector.tipText', { defaultValue: 'Your layout preference is saved automatically and will persist across sessions.' })}
        </p>
      </div>
    </div>
  );
};
