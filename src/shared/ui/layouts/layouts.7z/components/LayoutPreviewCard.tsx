import React from 'react';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

interface LayoutPreviewCardProps {
  active: boolean;
  image?: string;
  title: string;
  description: string;
  onClick: () => void;
  fallbackVariant?: string;
}

/**
 * LayoutPreviewCard - Visual preview card for layout selection
 * 
 * Shows layout preview with title, description, and active state
 * Falls back to CSS-based preview if no image provided
 */
export const LayoutPreviewCard: React.FC<LayoutPreviewCardProps> = ({
  active,
  image,
  title,
  description,
  onClick,
  fallbackVariant = 'boxed',
}) => {
  return (
    <button
      onClick={onClick}
      className={cn(
        'group relative flex flex-col rounded-lg border-2 transition-all duration-200',
        'hover:shadow-lg hover:scale-[1.02]',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2',
        active
          ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20'
          : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 hover:border-gray-300 dark:hover:border-gray-600'
      )}
    >
      {/* Active indicator */}
      {active && (
        <div className="absolute -top-2 -right-2 z-10 flex items-center justify-center size-6 rounded-full bg-blue-500 text-white shadow-lg">
          <Check className="size-4" />
        </div>
      )}

      {/* Preview */}
      <div className="relative aspect-video w-full overflow-hidden rounded-t-md bg-gray-100 dark:bg-gray-900">
        {image ? (
          <img
            src={image}
            alt={title}
            className="h-full w-full object-cover"
          />
        ) : (
          <LayoutFallbackPreview variant={fallbackVariant} />
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col gap-1 p-4 text-left">
        <h3 className={cn(
          'font-semibold text-sm',
          active ? 'text-blue-700 dark:text-blue-400' : 'text-gray-900 dark:text-gray-100'
        )}>
          {title}
        </h3>
        <p className="text-xs text-gray-600 dark:text-gray-400 line-clamp-2">
          {description}
        </p>
      </div>
    </button>
  );
};

/**
 * LayoutFallbackPreview - CSS-based layout preview when no image provided
 */
const LayoutFallbackPreview: React.FC<{ variant: string }> = ({ variant }) => {
  if (variant === 'boxed') {
    return (
      <div className="h-full w-full p-2 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900">
        <div className="h-full w-full flex gap-2">
          <div className="w-16 bg-white dark:bg-gray-700 rounded shadow-sm" />
          <div className="flex-1 bg-white dark:bg-gray-700 rounded shadow-sm" />
        </div>
      </div>
    );
  }

  if (variant === 'edge') {
    return (
      <div className="h-full w-full flex">
        <div className="w-16 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900" />
        <div className="flex-1 bg-gray-100 dark:bg-gray-900" />
      </div>
    );
  }

  if (variant === 'double-sidebar') {
    return (
      <div className="h-full w-full p-2 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900">
        <div className="h-full w-full flex gap-1">
          <div className="w-8 bg-white dark:bg-gray-700 rounded-l shadow-sm" />
          <div className="w-20 bg-white dark:bg-gray-700 shadow-sm" />
          <div className="flex-1 bg-white dark:bg-gray-700 rounded-r shadow-sm" />
        </div>
      </div>
    );
  }

  return (
    <div className="h-full w-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center">
      <span className="text-xs text-gray-500">Preview</span>
    </div>
  );
};
